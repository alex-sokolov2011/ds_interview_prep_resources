from functools import lru_cache
import pandas as pd

# recursive function to calculate num ways to get a sum 's' using 'n' dice
@lru_cache(maxsize=None)
def prob_sum(_sum, n):
    if n == 1:
        return 1 if 1 <= _sum <= 6 else 0
    if _sum < n or _sum > 6 * n:
        return 0

    return sum(prob_sum(_sum-k, n-1) for k in range(1, 7))

# function to calculate probs of landing on each cell for a given number of dice
def get_probs(num_dice):
    total_possibilities = 6 ** num_dice
    probs = {}

    # Loop through all possible sums when using 'num_dice' dice
    for s in range(num_dice, 6*num_dice + 1):
        cell = (s + 11) % 12 + 1
        probs[cell] = probs.get(cell, 0) + prob_sum(s, num_dice) / total_possibilities

    # Ensure all cells have a probability (fill missing cells with 0)
    for i in range(1, 13):
        if i not in probs:
            probs[i] = 0

    return probs

# Output the probabilities in a table format using pandas
def display_table():
    num_dice_list = [3, 6, 12]
    data = {num_dice: [get_probs(num_dice)[i] for i in range(1, 13)] for num_dice in num_dice_list}
    df = pd.DataFrame(data, index=range(1, 13))
    df.columns.name = "Dice"
    df.index.name = "Cell"
    print(df)

if __name__ == "__main__":
    display_table()